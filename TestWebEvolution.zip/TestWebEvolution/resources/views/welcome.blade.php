<html>
    <head>
        <link href="{{asset('css/style.css')}}" rel="stylesheet" />   
        
	</head>
	<body>
        
    <div class="grid">
        <div id="Header" class="bloc head">Je Suis l'Entete</div>
        
        <div id="sidebar-left" class="bloc2 left"><div id="inside-sidebar"></div></div>
        <div id="main"></div>
        <div id="sidebar-right" class="bloc2 right"></div>
        
        <div id="Footer" class="bloc foot">Je suis le pied de page</div>
    </div>
    </body>
    <script type="text/javascript" src="{{asset('js/jquery-1.10.2.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/jquery-ui-1.10.4.custom.min.js')}}"></script>
    <script>
	
  $(".bloc").draggable({
    revert: true
  });

  $(".bloc").droppable({
    accept: '.bloc',
    drop: function(event, ui) {
        var jHead  = $('.head').html();
        var jFoot = $('.foot').html();
	    $('.head').html(jFoot);
        $('.foot').html(jHead);
      
    }
  });

  $(".bloc2").draggable({
    revert: true
  });

  $(".bloc2").droppable({
    accept: '.bloc2',
    drop: function(event, ui) {
        var Left  = $('.left').html();
        var Right = $('.right').html();
        $('.left').html(Right);
        $('.right').html(Left);
        $("#inside-sidebar").draggable({
        containment: "parent"
        });
    }
  });

  $("#inside-sidebar").draggable({
    containment: "parent"
  });


</script>

        
</html>
